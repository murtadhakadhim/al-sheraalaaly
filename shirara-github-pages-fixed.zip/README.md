# شركة الشراع العالي للمقاولات العامة المحدودة

## Deploying to GitHub Pages

1. Create a new repository on GitHub (or use an existing one).
2. Upload `index.html` to the root of the repository (or push via git).
3. In the repository settings, go to **Settings → Pages**.
4. Under **Source**, select the branch (e.g. `main`) and the `/ (root)` folder, then save.
5. GitHub will publish your site at `https://<username>.github.io/<repository-name>/`.

## Notes

- This is a single, fully self-contained `index.html` file.
- All images, icons, and the downloadable PDF company profile are embedded directly in the file as data URIs — there are no external image/asset files to manage, and nothing will break when the repo is hosted under a subpath (e.g. `username.github.io/repo-name/`).
- The only external network requests are to Google Fonts (`fonts.googleapis.com` / `fonts.gstatic.com`) for the "IBM Plex Sans Arabic" typeface — these are standard CDN links and work identically on GitHub Pages.
- No design, content, layout, colors, fonts, spacing, images, or functionality were changed in any way.
